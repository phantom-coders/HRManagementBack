-- DropIndex
DROP INDEX `user_id_key` ON `user`;
